#!/bin/bash

bluetoothctl << EOF

discoverable off

EOF